// ЕДИНАЯ ТОЧКА ПРАВКИ ДАННЫХ КЛИНИКИ.
// Всё в этом файле, кроме слогана, — ПЛЕЙСХОЛДЕР демо-прототипа.
// Замените значения на реальные и поставьте isDemo: false: пометки «демо» исчезнут со всего сайта.

export const site = {
  isDemo: true,

  brand: "ЭМАЛЬ", // ПЛЕЙСХОЛДЕР {{BRAND}}
  descriptor: "ЭМАЛЬ · стоматология",
  slogan: "Лечение начинается с диагностики",
  domain: "https://emal-clinic.example", // ПЛЕЙСХОЛДЕР {{DOMAIN}}
  city: "Алматы", // ПЛЕЙСХОЛДЕР {{CITY}}

  phone: "+7 (700) 000-00-00", // ПЛЕЙСХОЛДЕР {{CONTACTS}}
  phoneHref: "tel:+77000000000",
  whatsapp: "https://wa.me/77000000000",
  telegram: "https://t.me/emal_clinic",
  instagram: "https://instagram.com/emal_clinic",
  email: "hello@emal-clinic.example",

  address: "ул. Примерная, 1", // ПЛЕЙСХОЛДЕР
  addressRegion: "Алматы",
  country: "KZ",
  hours: "Пн–Сб 09:00–20:00, Вс 10:00–16:00", // ПЛЕЙСХОЛДЕР
  hoursSchema: ["Mo-Sa 09:00-20:00", "Su 10:00-16:00"],
  directions: "Парковка во дворе, вход с улицы. Описание маршрута и ориентиры добавит клиника.", // ПЛЕЙСХОЛДЕР
  mapEmbed: "", // ПЛЕЙСХОЛДЕР: ссылка на iframe 2ГИС или Яндекс Карт
  geo: { lat: 43.2389, lng: 76.8897 }, // ПЛЕЙСХОЛДЕР

  developer: { label: "Разработка сайта", name: "AlexWebStudio", href: "https://alexwebstudio.ru" },

  legal: "ТОО «Название клиники», БИН 000000000000", // ПЛЕЙСХОЛДЕР
  license: "Лицензия на медицинскую деятельность № 00000 от 00.00.0000", // ПЛЕЙСХОЛДЕР

  // ПЛЕЙСХОЛДЕРЫ: подставить реальные значения клиники
  stats: {
    years: 12,
    patients: 15000,
    doctorsExperience: 7,
    rating: 4.9,
    reviews: 527,
  },
} as const;

export const demoNote = "Демо-прототип: цены, рейтинг и данные врачей условные.";

export function formatPrice(value: number) {
  return `${value.toLocaleString("ru-RU").replace(/ |\s/g, " ")} ₸`;
}

export function formatCount(value: number) {
  return value.toLocaleString("ru-RU").replace(/ |\s/g, " ");
}

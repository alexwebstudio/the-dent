// ПЛЕЙСХОЛДЕР: выдумывать отзывы нельзя. Добавьте реальные из 2ГИС и Яндекс,
// заполнив text и author, и поставьте placeholder: false.

export type Review = {
  author: string;
  source: "2ГИС" | "Яндекс";
  rating: number;
  text: string;
  placeholder: boolean;
};

export const reviews: Review[] = [
  { author: "Имя пациента", source: "2ГИС", rating: 5, text: "Место для реального отзыва из 2ГИС: текст появится после согласования с клиникой.", placeholder: true },
  { author: "Имя пациента", source: "Яндекс", rating: 5, text: "Место для реального отзыва из Яндекс Карт: текст появится после согласования с клиникой.", placeholder: true },
  { author: "Имя пациента", source: "2ГИС", rating: 5, text: "Место для реального отзыва из 2ГИС: текст появится после согласования с клиникой.", placeholder: true },
];

// ПЛЕЙСХОЛДЕР: имена условные, фото со стока. Вуз, ординатуру и сертификаты передаёт клиника.

export type Doctor = {
  slug: string;
  name: string;
  headline: string;
  role: string;
  specialization: string;
  experience: string;
  about: string;
  education: string[];
  serviceSlugs: string[];
  image: string;
  imageAlt: string;
};

const experience = "от 7 лет";
const education = [
  "Высшее медицинское образование: вуз и год — данные клиники",
  "Ординатура или резидентура: данные клиники",
  "Сертификаты и курсы: данные клиники",
];

export const doctors: Doctor[] = [
  {
    slug: "therapist",
    name: "Алия Нурланова",
    headline: "Алия *Нурланова*",
    role: "Стоматолог-терапевт",
    specialization: "Лечение кариеса и пульпита, реставрации, эстетика, гигиена",
    experience,
    about: "Сохраняет свои зубы, пока это возможно. Начинает со снимка и объясняет план простыми словами.",
    education,
    serviceSlugs: ["therapy", "esthetics", "hygiene"],
    image: "/images/doctors/therapist.jpg",
    imageAlt: "Алия Нурланова, стоматолог-терапевт клиники",
  },
  {
    slug: "implantologist",
    name: "Данияр Сапаров",
    headline: "Данияр *Сапаров*",
    role: "Хирург-имплантолог",
    specialization: "Имплантация, хирургия, протезирование",
    experience,
    about: "Планирует вмешательство по 3D-снимку и ведёт пациента от операции до коронки.",
    education,
    serviceSlugs: ["implantation", "surgery", "prosthetics"],
    image: "/images/doctors/implantologist.jpg",
    imageAlt: "Данияр Сапаров, хирург-имплантолог клиники",
  },
  {
    slug: "orthodontist",
    name: "Аружан Бектурова",
    headline: "Аружан *Бектурова*",
    role: "Ортодонт",
    specialization: "Брекет-системы и элайнеры",
    experience,
    about: "Рассчитывает движение каждого зуба и заранее показывает вам этапы лечения.",
    education,
    serviceSlugs: ["orthodontics"],
    image: "/images/doctors/orthodontist.jpg",
    imageAlt: "Аружан Бектурова, врач-ортодонт клиники",
  },
  {
    slug: "pediatric",
    name: "Тимур Ахметов",
    headline: "Тимур *Ахметов*",
    role: "Детский стоматолог",
    specialization: "Лечение и профилактика у детей",
    experience,
    about: "Работает в темпе ребёнка: сначала знакомство и доверие, потом лечение.",
    education,
    serviceSlugs: ["kids"],
    image: "/images/doctors/pediatric.jpg",
    imageAlt: "Тимур Ахметов, детский стоматолог клиники",
  },
];

export function getDoctor(slug: string) {
  return doctors.find((item) => item.slug === slug);
}
